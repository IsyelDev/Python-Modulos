from setuptools import setup
from struct import pack

setup(
    name="paquetes",
    version="1.0",
    description="Un paquete de saludar y Despedida",
    author="EMDT",
    author_email="delap@gmail.com",
    url="https://www.google.com",
    packages=["paquetes","paquetes.adios","paquetes.saludos"],
    scripts=["test.py"]
)

