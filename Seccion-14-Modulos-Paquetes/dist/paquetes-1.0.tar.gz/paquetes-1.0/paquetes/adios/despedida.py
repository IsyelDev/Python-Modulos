def bye(name):
    return f"Adios {name}"