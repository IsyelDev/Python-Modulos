#from paquetes.Saludos.greetings import Saludo
from Adios.despedida import bye

#saludito = Saludo()
calidad = bye("Papu")
print(calidad)