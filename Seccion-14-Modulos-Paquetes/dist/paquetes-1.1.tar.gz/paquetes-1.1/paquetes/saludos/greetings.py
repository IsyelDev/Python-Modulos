def greeting(name):
    return f"Hola {name}"

def bye(name):
    return f"Adios {name}"

class Saludo:
    def __init__(self):
        print("Hola saludos amigos")

if __name__=="__main__":
    greeting("Elmer")
