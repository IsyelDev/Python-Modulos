def bye(name):
    return f"Adios {name}"

def regreso():
    print("Regresamos con fuerza")